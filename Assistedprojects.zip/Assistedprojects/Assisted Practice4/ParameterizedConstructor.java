package interference_Collection;
class Constructor1{
	int id;
	String name;
	protected Constructor1(){
		System.out.println("Inside Constructor");
	}
	public Constructor1(int i,int j) {
		int k=i+j;
		System.out.println("addition of two number: "+k);
	}
	public Constructor1(int i,String j) {
		id=i;
		name=j;
		System.out.println(i+" is the id of "+j);
	}
	void display() {
		System.out.println("Inside display method");
	}
}
public class ParameterizedConstructor {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Constructor1 c=new Constructor1();
Constructor1 c1=new Constructor1(546,512);
Constructor1 c2=new Constructor1(546,"alex");
c.display();
c1.display();
	}
}
