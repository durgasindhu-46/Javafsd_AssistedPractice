package interference_Collection;
class Constructor{
	protected Constructor(){
		System.out.println("Inside Constructor");
	}
	void display() {
		System.out.println("Inside display method");
	}
}
public class ZeroParameterConstructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Constructor c=new Constructor();
c.display();
	}

}
