package interference_Collection;

public class StringOperations1 {
	StringOperations1(String s){
		System.out.println(s);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="abc";
		String s4="abc";

StringOperations1 s1=new StringOperations1("abcd");
System.out.println(s.equals(s4));
System.out.println(s.toUpperCase());
System.out.println(s.substring(2));
System.out.println(s.substring(1));
System.out.println(s.length());
System.out.println(s.charAt(1));
System.out.println(s.endsWith("c"));
System.out.println(s.equalsIgnoreCase(s4));
System.out.println(s.indexOf("b"));
System.out.println(s.toString());
System.out.println(s.codePointAt(2));//unicode char at specific index
System.out.println(s.codePointBefore(2));//before specific index
System.out.println(s.codePointCount(0,2));//char b/w indexes given
System.out.println(s.compareTo(s4));
System.out.println(s.compareToIgnoreCase(s4));//ignore case
System.out.println(s.concat(s4));
System.out.println(s.contains(s4));
System.out.println(s.hashCode());
String s3="demo is practice program";
System.out.println(s3.isEmpty());
System.out.println(s3.lastIndexOf("practice"));
System.out.println(s3.length());
System.out.println(s3.replace("practice", "java"));
System.out.println(s3);
System.out.println(s3.startsWith("demo"));
String s5="   hello";
System.out.println(s5.trim());

StringBuffer s2=new StringBuffer();
s2.append("Java");
s2.append(" is a good programming language");
System.out.println(s2.toString());
	}

}
