package interference_Collection;

import java.util.HashMap;
import java.util.Map;

public class HashMapExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> hm=new HashMap<Integer,String>();      
	      hm.put(1,"A");  
	      hm.put(3,"C"); 
	      hm.put(2,"B");    
	      hm.put(null, "H");
	      hm.put(4, "O"); 
	      System.out.println("\nThe elements of Hashmap are ");  
	      for(Map.Entry m:hm.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
	 
			System.out.println("Get element at key 3: "+hm.get(3));
		
			System.out.println("Get element at key 0: "+hm.get(0));
			
			System.out.println("Get element at key null: "+hm.get(null));//as key is null value soni is not added in map
			
			System.out.println("Get element at key 6: "+hm.get(6));//as element is not present it will give you null answer
			
			//remove element by key
			
			hm.remove(3);
			
			System.out.println(hm);
			

			for(Map.Entry m: hm.entrySet()) {
				
				System.out.println(m.getKey()+" , "+m.getValue());
			}
			//hashmap is the implementation of map.
			//it inherits hashmap class
			//it maintains insertion order
			//methods: put,get,remove,getKey
			//it allows null values
			
			
	}

}
