package interference_Collection;

public class CallMethod {
	int v=700;
	void change(int v) {
		v=v+200;//changes will be in the local variable only
	}
public static void main(String[] args) {
		// TODO Auto-generated method stub
		CallMethod c=new CallMethod();
		System.out.println("before making change: "+c.v);
		c.change(600);
		System.out.println("after making change: "+c.v);

	}

}
