package interference_Collection;

public class Method_Overload {
	int add(int i,int j) {
		return i+j;
	}
	int add(int i,int j,int k) {
		
		//System.out.println(i+j+k);
		//System.out.println((i+j+k));
		return i+j+k;
	}
float add(int i,int j,float k) {
		return i+j+k;
	}
public void area(int b,int h)
{
     System.out.println("Area of Triangle : "+(0.5*b*h));
}
public void area(int r) 
{
     System.out.println("Area of Circle : "+(3.14*r*r));
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Method_Overload m=new Method_Overload();
		System.out.println("addition of two numbers: "+m.add(1, 2));
		System.out.println("addition of three numbers: "+m.add(1, 2,3));
		System.out.println("addition of float and int values: "+m.add(2,3,4.0f));
	   m.area(15,30);
	   m.area(6);
	}

}
