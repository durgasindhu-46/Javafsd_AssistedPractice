package interference_Collection;
public class Method {
public void add(int a,int b) {
	int k=a*b;
	//return k;
	//as void is used so no return
	System.out.println("addition of two numbers: "+k);
}
public float mul(int a,float b) {
	float k=a+b;
	return k;
	
}
	public static void main(String[] args) {
Method m=new Method();
m.add(4,5);
float n=m.mul(30,34.89f);
System.out.println("multiplication of two numbers: "+n);
	}

}
