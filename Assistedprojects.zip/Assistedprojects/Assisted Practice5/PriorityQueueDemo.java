package interference_Collection;
import java.util.*;
public class PriorityQueueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue<Integer> pQueue= new PriorityQueue<Integer>(); 
		pQueue.add(68);
		pQueue.add(99);
		pQueue.add(89);
		pQueue.add(47);
	 
		//four operations poll.peek,remove,element
		//print priority queue
		
		System.out.println(pQueue);
		
		
		//print the top element of priority queue
		System.out.println("Top Element: " + pQueue.peek());
		//retrieves not remove,null if queue is empty
		
		//printing the top element and removing it from the priority queue container
		System.out.println("Printing the top element and removing: "+pQueue.poll());
		//retrieves and remove head of the queue, null if queue is empty
		System.out.println(pQueue);
		
		//print the top element of priority queue
		System.out.println("Top Element: " + pQueue.peek());
		
		
		//remove element from pqueue
		
		pQueue.remove(68);
	//retrieves and remove,exception if queue is empty
		
		System.out.println("After Remove : "+pQueue);
		System.out.println("To find element : "+pQueue.element());
		//retrieves not remove,null if queue is empty
		System.out.println("After Remove : "+pQueue);
		
		Iterator<Integer> itr=pQueue.iterator();
		while(itr.hasNext())
		{
		System.out.println(itr.next());
		}
		
	    for(Integer s:pQueue){
			System.out.println(pQueue);
		}
		//priority queue doesn't allow null values
				// we can't create  priority queue that are non comparable
		
	}

}
