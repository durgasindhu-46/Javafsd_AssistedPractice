package interference_Collection;
import java.util.*;
public class LinkedHashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//linked hashset is an ordered version of hashset
				//whenever iteration order is needed to be maintained this class is used
				//while iterating elements are fetched as per they were inserted
				//do not allows duplicate values
				LinkedHashSet<String> linkedset= new LinkedHashSet<String>();
				
				linkedset.add("A");
				linkedset.add("B");
				linkedset.add("C");
				linkedset.add("D");
				
				//note: do not allows duplicate values, so 'A' will not be added but 'E' will be added
				linkedset.add("A");
				linkedset.add("E");
				linkedset.add(null);
				
				System.out.println("Size: "+linkedset.size());
				
				System.out.println(linkedset);
				
				
				System.out.println("Contains E: "+linkedset.contains("E"));
				
				linkedset.remove(null);
				
				System.out.println("After Remove: "+linkedset);
				
				Iterator<String> itr=linkedset.iterator();
				while(itr.hasNext())
				{
				System.out.println(itr.next());
				}
				
			    for(String s:linkedset){
					System.out.println(linkedset);
				}
				
	
	}

}
