package interference_Collection;
import java.util.*;

public class TreeSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Set<String> set = new TreeSet<String>(); 
	
		set.add("Banana");
		set.add("Cherry");
		set.add("Almond");
		set.add("Apple");
		//set.add(null); null is not allowed in treeset
		
		System.out.println(set);
		
		System.out.println("Size: "+set.size());
		
		System.out.println("Contains: "+ set.contains("Banana"));
		
		Iterator<String> itr=set.iterator();
		while(itr.hasNext())
		{
		System.out.println(itr.next());
		}
		
	    for(String s:set){
			System.out.println(set);
		}
		//the order of the element is maintained by the set using their natural ordering 
		//tree set is one of the most imp implementation of sorted set interface in java
	}

}
