package interference_Collection;
import java.util.*;
public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     HashSet<Integer> set= new HashSet<Integer>();
		
		set.add(15);
		set.add(55);
		set.add(2);
		set.add(36);
		set.add(67);
		set.add(67);//no duplicates
		set.add(null);//allow null
		
		System.out.println("Size: "+set.size());
		
		System.out.println(set);
		
		System.out.println("Contains: "+ set.contains(55));
		
		set.remove(null);
		System.out.println(set);
		 HashSet<String> set1= new HashSet<>();
			
			set1.add("l");
			set1.add("y");
			set1.add("R");
			set1.add("F");
			set1.add(null);
			for(String d:set1) {
				System.out.println(d);
			}
			System.out.println("Size: "+set1.size());
			
			System.out.println(set1);
			
			System.out.println("Contains: "+ set1.contains("S"));
			
			set1.remove(null);
			System.out.println(set1);
			
			Iterator<String> itr=set1.iterator();
			while(itr.hasNext())
			{
			System.out.println(itr.next());
			}
			
		    for(String s:set1){
				System.out.println(set1);
			}
		    //hashset class implemensts set interface
			//no guarantee that the constant order of element over time
			//methods add, remove,contains and size;
	}

}
