package interference_Collection;
import java.util.*;
import java.util.Iterator;

public class VectorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String> a= new Vector<String>();
		System.out.println("Size:"+a.size());
		a.add("red");
		a.add("green");
		a.add("orange");
		a.add("yellow");
		System.out.println(a);
		a.add(1,"pink");
		a.add(0,"violet");
		System.out.println(a);
		a.remove(3);
		System.out.println(a);
		System.out.println("After Adding an Elements :"+a.size());
		a.add(null);// list contains null value
		
		System.out.println("After Adding null Element :"+a.size());
		System.out.println(a);

		System.out.println("List Contains grey? :"+a.contains("grey"));
         a.remove(null);
         System.out.println(a.get(2));
		System.out.println(a);
		Iterator<String> itr=a.iterator();
		while(itr.hasNext())
		{
		System.out.println(itr.next());
		}
		a.ensureCapacity(10);
	    for(String s:a){
			System.out.println(a);
		}
		System.out.println(a.isEmpty());
		// 1. arraylist is not synchronized but vector is synchronised
				// 2. array list is not alegacy class. it was introduced in JDK12 but vector is legacy class
				// 3. arraylist is fast because it is not synchronized but vector is slow becuase it is synchronised
	}

}
