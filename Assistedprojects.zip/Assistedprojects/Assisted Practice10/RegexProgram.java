package interference_Collection;
import java.util.regex.*;
public class RegexProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String pattern = "[a-z]+?";//one char it checks
		String exp = "Regular Expressions";
		//creating a pattern to be searched
		Pattern p = Pattern.compile(pattern);
		//Searching pattern in the words
		Matcher e = p.matcher(exp);
		//
		while (e.find())
			//printing the starting and till end of pattern in the text using methods
	      	System.out.println( exp.substring( e.start(), e.end() ) );

	}

}
