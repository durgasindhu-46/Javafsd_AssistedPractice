package interference_Collection;

public class StaticInnerClass {
 static class A{
	public static void hello() {
		System.out.println("static inner class");
}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticInnerClass.A s=new StaticInnerClass.A();
		 s.hello();
	}

}
