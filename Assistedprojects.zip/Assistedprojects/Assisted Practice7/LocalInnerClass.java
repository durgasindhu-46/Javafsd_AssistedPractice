package interference_Collection;

public class LocalInnerClass {
	private String msg="inner class";
	void test() {
		class Inner{
			void local() {
				System.out.println("Inside local class");
				System.out.println(msg);
			}
		}
		Inner obj=new Inner();
		obj.local();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
LocalInnerClass l=new LocalInnerClass();
l.test();
	}

}
