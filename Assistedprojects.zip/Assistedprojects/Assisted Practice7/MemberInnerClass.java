package interference_Collection;

public class MemberInnerClass {
private String message="hello";
class Inner{
	void hello() {
		System.out.println("member inner class");
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
MemberInnerClass m=new MemberInnerClass();
System.out.println(m.message);
MemberInnerClass.Inner innerm=m.new Inner();
innerm.hello();
	}

}
