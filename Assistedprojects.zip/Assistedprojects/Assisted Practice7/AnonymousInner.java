package interference_Collection;
abstract class AnonymousInnerClass {
	   abstract void test();
	}

public class AnonymousInner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnonymousInnerClass i = new AnonymousInnerClass() {

	         public void test() {
	            System.out.println("Anonymous Inner Class");
	         }
	      };
	      i.test();

	}

}
