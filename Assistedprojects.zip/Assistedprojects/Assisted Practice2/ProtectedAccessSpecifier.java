package BuildingBlocks;


public class ProtectedAccessSpecifier {
	protected void dog() 
    { 
        System.out.println("This is dog method"); 
    } 

}
