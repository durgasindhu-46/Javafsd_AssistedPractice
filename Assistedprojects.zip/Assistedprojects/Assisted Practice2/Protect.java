package BuildingBlocks1;
import BuildingBlocks.*;
public class Protect extends ProtectedAccessSpecifier{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Protect p=new Protect();
        p.dog();
	}

}
