package BuildingBlocks;
class Access{
	void defaultmethod() {
		System.out.println("This is default method");
	}
}
public class DefaultAccessSpecifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Dafault Access Specifier");
		Access obj = new Access(); 		  
        obj.defaultmethod(); 

	}

}
