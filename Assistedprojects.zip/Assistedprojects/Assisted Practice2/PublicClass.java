package BuildingBlocks;

public class PublicClass {
	public void publicmethod() 
    { 
        System.out.println("This is Public Access Specifiers method"); 
    } 

}
