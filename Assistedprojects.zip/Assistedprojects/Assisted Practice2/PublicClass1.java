package BuildingBlocks1;
import BuildingBlocks.*;
public class PublicClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
PublicClass pc=new PublicClass();
pc.publicmethod();
	}

}
