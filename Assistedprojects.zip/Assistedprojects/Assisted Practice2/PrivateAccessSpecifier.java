package BuildingBlocks;
class AccessPrivate{
	private void dog() {
		System.out.println("This is dog method");
	}
	void cat() {
		System.out.println("This is cat method");
	}
}
public class PrivateAccessSpecifier {
	private void animal() {
		System.out.println("This is animal method");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Private Access Specifier");
		PrivateAccessSpecifier obj=new PrivateAccessSpecifier();
		AccessPrivate a=new AccessPrivate();
		// WE cannot access private method of another class
		//a.dog();
		a.cat();
		obj.animal();
	}

}
