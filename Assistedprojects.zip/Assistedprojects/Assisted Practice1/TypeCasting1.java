package BuildingBlocks;

public class TypeCasting1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//boolean
				if(true)
				System.out.println("boolean true");
				else 
				System.out.println("boolean false");	
				
				//implicit/widening
		int a=10;
		float f=a;
		double d=f;
		double e=a;//we cannot covert float or double to integer datatype
		long l=a;
		System.out.println(a);
		System.out.println(f);
		System.out.println(d);
		System.out.println(e);
		System.out.println(l);
		byte b=90;
		int c=b;
		float g=b;
		double h=b;
		short i=b;
		System.out.println(b);
		System.out.println(c);
		System.out.println(g);
		System.out.println(h);
		System.out.println(i);
		//explicit/ narrowing
		System.out.println("explicit");
		float x=10.5f;// if we give dot and value for float then f should be given
		int y=(int)x;//10
		System.out.println(x);
		System.out.println(y);

		float m=10.5f;// if we give dot and value for float then f should be given
		float n=(int)m;//10.0
		System.out.println(m);
		System.out.println(n);
		int w=127;
		int v=(byte)w;
		System.out.println(w);
		System.out.println(v);

		//float p=128.0f;
		//float q=(int)p;
		int p=128;
		int q=(byte)p;
		System.out.println(p);
		System.out.println(q);

		int r=130;
		int s=(byte)r;
		System.out.println(r);
		System.out.println(s);
		//char in implicit
		char s1='a';
		char s3='A';
		int s2=s1, s4=s3;
		System.out.println(s2);
		System.out.println(s4);
			//explicit
		int v1=97;
		char v2=(char)v1;
		System.out.println(v2);
		int v3=(char)v1;
		System.out.println(v3);
			
	}

}
