package BuildingBlocks;
import java.util.Scanner;
public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
    //Implicit Conversion of char
		System.out.println("Implicit Type Casting");
		System.out.println("enter a character:");
		char a1=sc.next().charAt(0);
		System.out.println("Value in char: "+a1);
		System.out.println("Converting char to number");
		//character to byte,short conversion is not possible
		//byte is 8 bit, short is 16bit and char is 16bit"
		//int 32 bit
		int a2=a1;
		System.out.println("int value of char: "+a2);
		//float 32 bit
		float a3=a1;
		System.out.println("float value of char: "+a3);
		//long 64 bit
		long a4=a1;
		System.out.println("long value of char: "+a4);
		//double 64 bit
		double a5=a1;
		System.out.println("double value of char: "+a5);
		System.out.println(" ");
		//Explicit Conversion of char
		System.out.println("Explicit Type Casting");
		System.out.println("Converting char to byte and short");
		byte c1=(byte)a1;
		System.out.println("byte to char conversion:"+c1);
		short c2=(short)a1;
		System.out.println("short to char conversion:"+c2);
		System.out.println(" ");
		System.out.println("Converting number to char");
		byte b1=97;
		char b2=(char)b1;
		System.out.println("byte to char conversion of 97:"+b2);
		int b3=b1;
		char b4=(char)b3;
		System.out.println("int to char conversion of 97:"+b4);
		float b5=b3;
		char b6=(char)b5;
		System.out.println("float to char conversion of 97:"+b6);
		long b7=100;
		char b8=(char)b7;
		System.out.println("Long to char conversion of 100:"+b8);
		double b9=112;
		char b10=(char)b9;
		System.out.println("double to char conversion of 112:"+b10);
		short b11=(short)b9;
		System.out.println("double to short conversion of 112:"+b11);
		char b12=(char)b11;
		System.out.println("short to char conversion of 112:"+b12);
		System.out.println(" ");
		//String Conversion
		System.out.println("String to number Conversion");
		String d="100";
		int n=Integer.parseInt(d);
		System.out.println("String to Integer conversion of 100:"+n);
		float n1=Float.parseFloat(d);
		System.out.println("String to Float conversion of 100:"+n1);
		double n2=Double.parseDouble(d);
		System.out.println("String to double conversion of 100:"+n2);
		byte n3=Byte.parseByte(d);
		System.out.println("String to byte conversion of 100:"+n3);
		short n4=Short.parseShort(d);
		System.out.println("String to short conversion of 100:"+n4);
		long n5=Long.parseLong(d);
		System.out.println("String to long conversion of 100:"+n5);
		double n6=Long.parseLong(d);
		System.out.println("Long to double conversion of 100:"+n6);
		System.out.println("");
		System.out.println("Number to String Conversion");
		int e=99;
		String s=String.valueOf(e);
		System.out.println("Int to String Conversion of 99:"+s);
		float f=e;
		String s1=String.valueOf(f);
		System.out.println("Float to String Conversion of 99:"+s1);
		double g=f;
		String s2=String.valueOf(g);
		System.out.println("Double to String Conversion of 99:"+s2);
		long h=e;
		String s3=String.valueOf(h);
		System.out.println("Long to String Conversion of 99:"+s3);
		Byte i=(byte)e;
		String s4=String.valueOf(i);
		System.out.println("Byte to String Conversion of 99:"+s4);
		short j=(short)e;
		String s5=String.valueOf(j);
		System.out.println("Short to String Conversion of 99:"+s5);
	}

}
