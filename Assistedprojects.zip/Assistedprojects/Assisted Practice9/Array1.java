package interference_Collection;

import java.util.Scanner;

public class Array1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 //dynamically taking inputs
	      Scanner sc=new Scanner(System.in);
	      System.out.println("enter number of elements into array:");
	      int n=sc.nextInt();
	      int[] c=new int[n];
	      System.out.println("enter the elements into array:");
	      for(int i=0;i<n;i++) {
	    	 c[i]=sc.nextInt();
	      }
	      for(int i=0;i<c.length;i++) {
	  		System.out.println("Elements of array c:"+c[i]);
	  		}

	}

}
