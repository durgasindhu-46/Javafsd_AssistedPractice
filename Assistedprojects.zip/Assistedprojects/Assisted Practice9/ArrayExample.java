package interference_Collection;

import java.util.Scanner;

public class ArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//single dimensional array
		int a[]= {10,20,30,40,50};
		for(int i=0;i<a.length;i++) {
		System.out.println("Elements of array a: "+a[i]);
		}

		System.out.println();		
		for(int a1: a) {
			System.out.print(a1+ " ");
		}
		System.out.println();	
		//multidimensional array
		int[][] b = {{2, 4, 6}, {3, 6, 9},{6,7,8}};
		      
		      System.out.println("\nLength of row 1: " + b[0].length);

				for (int row=0; row<3; row++) {
					
					for(int col=0;col<3;col++) {
						
						System.out.print(b[row][col]+"\t");
					}
					System.out.println();
					
				}
	}

}
