package AssistedProject3;

class TableDemo {
	 synchronized void printTable(int n) {
			for (int i = 1; i <= 5; i++) {
				System.out.println(n * i);
				try {
					Thread.sleep(1000);
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		}
	}
	class MyThread5 extends Thread {
		TableDemo t;
		MyThread5(TableDemo t) {
			this.t = t;
		}
		public void run() {
			t.printTable(5);
		}
	}
	 class MyThread6 extends Thread{ 
		 TableDemo t; 
		 MyThread6(TableDemo t){ 
			 this.t=t; 
			 }
		 public void run(){ 
			 t.printTable(100); 
			 } 
	}
	 
	public class  BlockSynchronization1 {
		public static void main(String args[]) {
			TableDemo obj = new TableDemo();// only one object
			MyThread5 t1 = new MyThread5(obj);
			 MyThread6 t2=new MyThread6(obj);
			t1.start();
			 t2.start();
		}
	}

