package AssistedProject4;

public class TryCatch{ 
	static void getInfo(){
		int arr[]={7};//arr[0]=7
		System.out.println(arr[2]);
	}
	    public static void main(String args[]) 
	    {
	    	 try{	
	    			getInfo();
	    			}
	        catch (ArrayIndexOutOfBoundsException e) 
	        {
	        	System.out.println(e.getMessage());
	            System.out.println("Array index is out of bounds!"); 
	        }
	    	 catch(Exception e){
	 			e.printStackTrace();
	 		}
	    }
}


