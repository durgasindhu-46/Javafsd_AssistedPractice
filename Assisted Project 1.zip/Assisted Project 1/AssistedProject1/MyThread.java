package AssistedProject1;

	public class MyThread extends Thread
	{
	 	public void run()
	 	{
	  		System.out.println("concurrent thread started running....");
	}
	 	public static void main( String args[] )
	 	{
	  		MyThread t = new  MyThread();
	  		MyThread t1 = new  MyThread();
	  		t.start();
	  		t1.start();
	 	}
	}


