package AssistedProject8;
class Parent {
void methodA()
{
	System.out.println("method a");//parent class
}
}
class Child1 extends Parent{
	void methodB()
	{
		System.out.println("method b");	
	}
}
class Child extends Child1{
	void methodc() {
		System.out.println("method c");
	}
}
public class MultilevelInheritance{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Child c=new Child();
    c.methodA();
    c.methodB();
    c.methodc();
	}


}
