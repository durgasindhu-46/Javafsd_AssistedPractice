package AssistedProject8;
public class EncapsulationDemo 
{     
    public static void main (String[] args)  
    { 
        Encapsulation1 obj = new Encapsulation1(); 
        obj.setName("Sonia"); 
        obj.setAge(22);  
        obj.setRoll(501); 
        System.out.println("My name: " + obj.getName()); 
        System.out.println("My age: " + obj.getAge()); 
        System.out.println("My roll: " + obj.getRoll());      
    } 
}


