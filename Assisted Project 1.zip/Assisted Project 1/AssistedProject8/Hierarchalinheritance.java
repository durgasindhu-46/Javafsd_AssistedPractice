package AssistedProject8;

class A{
	void text()
	{String s="A class";
		System.out.println("Text:"+s);
	}
}
class B extends A{
	void add() {
		int a=10,b=20;
		int k=a+b;
		System.out.println("Addition is:"+k);
	}
}
class C extends A{
	void mul() {
		int n=10,m=20;
		int l=n*m;
		System.out.println("Multiplication is:"+l);
	}
}
public class Hierarchalinheritance {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
B b=new B();
b.add();
b.text();
C c=new C();
c.mul();
c.text();
	}

}
