package AssistedProject5;

import java.util.Scanner;

public class ThrowsDemo {
	void Division() throws ArithmeticException
    {
		 Scanner s=new Scanner(System.in);
	     System.out.println("enter a value:");
	int a=s.nextInt();
	System.out.println("enter b value:");
	int b=s.nextInt();
        int rs;
        rs = a / b;
        System.out.print("\nThe result is : " + rs);
    }
     public static void main(String[] args)
    {
       ThrowsDemo T = new ThrowsDemo();
         try
        {
            T.Division();
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("\nError : " + Ex.getMessage());
        }
        System.out.print("\nEnd of program.");
    }

}
