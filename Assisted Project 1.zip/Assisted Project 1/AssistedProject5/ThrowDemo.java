package AssistedProject5;
import java.util.Scanner;
public class ThrowDemo {
	public static void main(String[] args)
    {
     Scanner s=new Scanner(System.in);
     System.out.println("enter a value:");
int a=s.nextInt();
System.out.println("enter b value:");
int b=s.nextInt();
        int rs;
        try
        {
            if(b==0)        
                throw(new ArithmeticException("Can't divide by zero."));
            else
            {
                rs = a / b;
                System.out.print("\nThe result is : " + rs);
            }
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("\nError : " + Ex.getMessage());
        }

        System.out.print("\nEnd of program.");
    }

}
