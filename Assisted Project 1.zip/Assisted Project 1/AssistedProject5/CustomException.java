package AssistedProject5;

class CustomExceptionHandler extends Exception  {
	    public CustomExceptionHandler(String s) 
	    { 
	        super(s); 
	    } 
	} 
	public class CustomException
	{ 
	    public static void main(String args[]) 
	    { 
	        try
	        { 
	            throw new CustomExceptionHandler("temp"); 
	        } 
	        catch (CustomExceptionHandler ex) 
	        { 
	            System.out.println("Caught"); 
	            System.out.println(ex.getMessage()); 
	        } 
	    } 
	}


