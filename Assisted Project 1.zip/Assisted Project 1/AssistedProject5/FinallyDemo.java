package AssistedProject5;

import java.util.Scanner;

public class FinallyDemo {

public static void main(String[] args)
{
	Scanner s=new Scanner(System.in);
    System.out.println("enter a value:");
int a=s.nextInt();
System.out.println("enter b value:");
int b=s.nextInt();

    try
    {
       int r = a / b;
       System.out.print("\nThe result is : " +r);
    }
    catch(ArithmeticException Ex)
    {Ex.printStackTrace();
       // System.out.print("\nError : " + Ex.getMessage());
    }
    finally
    {
		System.out.print("\nEnd of the program");

	}

}
}
