package com.spexample;
public class ProductException extends RuntimeException {

}