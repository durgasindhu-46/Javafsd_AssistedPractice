package pkg1;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
public class AnnotationTest {
	@Test
	void test() {
		fail("Not yet implemented");
	}
}
