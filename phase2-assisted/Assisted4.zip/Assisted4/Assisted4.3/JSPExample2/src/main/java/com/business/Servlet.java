package com.business;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.time.*;
@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String user = request.getParameter("user");
		
		//redirecting to display details
		//Date createTime = new Date(session.getCreationTime());
		   // Get last access time of this Webpage.
		 //  Date lastAccessTime = new Date(session.getLastAccessedTime());
		HttpSession session = request.getSession();		
		
		LocalDateTime t=LocalDateTime.now();
		session.setAttribute("user", user);
		session.setAttribute("date", t);	
		response.sendRedirect("display.jsp");		
		
	}

}


