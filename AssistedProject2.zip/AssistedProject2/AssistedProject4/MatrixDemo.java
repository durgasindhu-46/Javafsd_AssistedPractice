package AssistedProject4;

public class MatrixDemo {
	public static void main(String[] args) 
	{
	       		int r1 = 3, c1 = 2;
	        		int r2 = 2, c2 = 3;
	        		int[][] firstMatrix = { {3, 5}, {4, 0}, {5,7} };
	        		
	        		int[][] secondMatrix = { {4,7,0}, {5,8,-2}};
	int[][] product = multiplyMatrices(firstMatrix, secondMatrix, r1, r2, c1, c2);
	//method to display values of matrix
	displayProduct(product);
	    	}

	public static int[][] multiplyMatrices(int[][] firstMatrix, int[][] secondMatrix, int r1, int r2, int c1, int c2) 
	{
	//it works only when columns of first matrix is equals to rows of second
	        		int[][] product = new int[r1][c2];
	        		for(int i = 0; i < r1; i++) 
	{
	            			for (int j = 0; j < c2; j++) 
	{
	                			for (int k = 0; k < c1; k++) 
	{
	                    				product[i][j] += firstMatrix[i][k] * secondMatrix[k][j];
	                			}
	            			}
	}	
	     return product;   	 	
	    	}
	public static void displayProduct(int[][] product) 
	{
	        		System.out.println("Product of two matrices is: ");
	        		for(int[] row : product) 
	{
	            			for (int column : row) 
	{
	                			System.out.print(column + "    ");
	            			}
	            			System.out.println();
	        		}
	    	}
}
