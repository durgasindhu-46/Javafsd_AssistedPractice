package AssistedProject1;
public class LeftArrayRotate {
	public static void rotate(int arr[], int k, int n)
    {
        int d = 1;
        while (d <= k) {
            int last = arr[0];
            for (int i = 0; i < n - 1; i++) {
                arr[i] = arr[i + 1];
            }
            arr[n - 1] = last;
            d++;
        }
 
    }
     
    public static void main(String[] args)
    {
        int arr[] = { 1,2,3,4,5,6,7,8,9 };
        int N = arr.length;
        int k = 5;
        //original array
        System.out.println("Original array:");
        for (int i = 0; i < N; i++) {
            System.out.print(arr[i] + " ");
        }
        rotate(arr, k, N);
        System.out.println("\nLeft rotate:");
        for (int i = 0; i < N; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}
